import os
import sys
import torch
import torch.nn as nn
import torchvision.transforms as transforms
import math


import importlib
import torchvision.models as models

VECTOR_LEN = 512


class AutoRoute(nn.Module):
    def __init__(self):
        super(AutoRoute, self).__init__()
        # self.flatten = nn.Flatten(1, -1)
        self.fc1 = nn.Linear(VECTOR_LEN*2*10, VECTOR_LEN*5)
        self.drop1 = nn.Dropout(0.6)
        self.act1 = nn.Tanh()
        self.fc2 = nn.Linear(VECTOR_LEN*5, 1)
        self.drop2 = nn.Dropout(0.2)
        self.activate = nn.Softmax(dim=-1)

    def forward(self, x):
        # x = self.flatten(x)
        x = self.fc1(x)
        x = self.drop1(x)
        x = self.act1(x)
        x = self.fc2(x)
        x = self.drop2(x)
        x = self.activate(x)
        return x

    def _initialize_weights(self):
        # 使用均匀分布初始化权重
        for m in self.modules():
            if isinstance(m, nn.Linear):
                nn.init.kaiming_uniform_(m.weight, a=math.sqrt(5))  # Kaiming 初始化
                if m.bias is not None:
                    nn.init.zeros_(m.bias)  # 偏置初始化为0


class Classification5MModel(nn.Module):
    def __init__(self, package_name, module_name, class_name, is_moe, is_auto_route):
        super(Classification5MModel, self).__init__()
        module = importlib.import_module(f"{package_name}.{module_name}")
        obj = getattr(module, class_name)
        self.base_model = obj(is_moe)
        self.router = AutoRoute()
        self.is_auto_route = is_auto_route
        self.conv = nn.Conv2d(5, 3, 3, 1, 1)
        self.model = models.resnet18(weights=models.ResNet18_Weights.DEFAULT)
        self.model.fc = nn.Sequential(nn.Linear(self.model.fc.in_features, 150),
                                      nn.Dropout(0.2),
                                      nn.Linear(150, 30),
                                      nn.Dropout(0.2),
                                      nn.Linear(30, 5),
                                      nn.Softmax(dim=-1))

    def load_base_model(self, model_path, model_head):
        self.base_model.load_models(model_path, model_head)
        self.base_model.eval()

    def forward(self, x, mask_code):
        _, en_s_list, en_i_list = self.base_model(x, mask_code)
        b, c, l = en_i_list.size()
        en_s_list = en_s_list.reshape(b, c // 10, l*10)
        en_i_list = en_i_list.reshape(b, c // 10, l * 10)
        b, c, l = en_i_list.size()
        en_s_list = torch.mean(en_s_list, dim=-2)
        en_s_list = en_s_list.reshape(b, 1, l)
        y = torch.cat((en_s_list, en_i_list), dim=1)
        y = y.cuda()
        if self.is_auto_route == 1:
            r = self.router(y)
            y = r * y
        y = y.reshape(b, 5, 32*5, 32*2)
        y = self.conv(y)
        y = self.model(y)
        return y

    def set_train_mode(self):
        self.base_model.eval()
        self.model.train()

    def set_eval_mode(self):
        self.base_model.eval()
        self.model.eval()

    def freeze_base_model(self):
        for param in self.base_model.parameters():
            param.requires_grad = False  # 冻结所有参数

    def freeze_auto_router(self):
        for param in self.router.parameters():
            param.requires_grad = False  # 冻结所有参数

    def thaw_auto_router(self):
        for param in self.router.parameters():
            param.requires_grad = True  # 冻结所有参数

    def save_model(self, file_path, file_head):
        save_dir = os.path.join(file_path, file_head + ".pth")
        print("save_model:", save_dir)
        torch.save(self.state_dict(), save_dir)

    def load_model(self, file_path, file_head):
        load_dir = os.path.join(file_path, file_head + ".pth")
        print("load_model:", load_dir)
        self.load_state_dict(torch.load(load_dir))
