import os
import sys
import torch
import torch.nn as nn
import torchvision.transforms as transforms
import math
import importlib
import torchvision.models as models


class AutoRouter(nn.Module):
    def __init__(self, vector_len):
        super(AutoRouter, self).__init__()
        self.fc1 = nn.Linear(vector_len * 2 * 10, vector_len * 5)
        self.drop1 = nn.Dropout(0.6)
        self.act1 = nn.Tanh()
        self.fc2 = nn.Linear(vector_len * 5, 1)
        self.drop2 = nn.Dropout(0.2)
        self.activate = nn.Softmax(dim=-2)
        self.prior_knowledge = torch.tensor([0.6, 0.3, 0.1, 0.05, 0.05]).cuda()

    def forward(self, x):

        x = self.fc1(x)
        x = self.drop1(x)
        x = self.act1(x)
        x = self.fc2(x)
        x = self.drop2(x)
        b, c, l = x.size()
        x = x.reshape(b, c)
        x = x * self.prior_knowledge
        x = x.reshape(b, c, l)
        x = self.activate(x)
        y = torch.clone(x)
        y = torch.flatten(y)
        # print("+"*50, y, "+"*50)
        return x

    def _initialize_weights(self):
        # 使用均匀分布初始化权重
        for m in self.modules():
            if isinstance(m, nn.Linear):
                nn.init.kaiming_uniform_(m.weight, a=math.sqrt(5))  # Kaiming 初始化
                if m.bias is not None:
                    nn.init.zeros_(m.bias)  # 偏置初始化为0
