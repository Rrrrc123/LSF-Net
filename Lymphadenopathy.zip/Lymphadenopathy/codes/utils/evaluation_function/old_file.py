import numpy as np
import torch
from torch.utils.data import DataLoader
from codes.utils.r_common import *
from sklearn.metrics import (
    matthews_corrcoef,  # 计算MCC
    balanced_accuracy_score,  # 计算平衡准确率
    f1_score,  # 计算F1分数
    recall_score,  # 计算召回率
    roc_auc_score,  # 计算AUC
    average_precision_score,  # 计算平均精确度
    precision_score,  # 计算精确率
    accuracy_score,
    confusion_matrix,
    classification_report
)


def get_models_performance_evaluation(t_model, t_datasets, modal_prob_list):
    datasets_len = t_datasets.get_dataset_count()
    data_loader = DataLoader(t_datasets, batch_size=1, shuffle=False, num_workers=0)
    y_pred_prob = np.zeros((datasets_len, 5))  # 5分类的概率值
    y_pred = np.zeros(datasets_len)  # 预测类别 # [2,3,4,1,0]
    y_labels = np.zeros(datasets_len)  # 原始标签的类别 # [1,2,3,4,0]
    t_model.eval()
    train_correct_sum = 0
    train_simple_cnt = datasets_len
    with torch.no_grad():
        for i, data in enumerate(data_loader, 0):
            inputs = data['inputs']
            labels = data['labels']
            inputs = torch.transpose(inputs, 1, 2)
            inputs = inputs.cuda()
            labels = labels.cuda()
            # mask_code = [1, 1, 1, 1]
            mask_code = mask_code_generator(len(modal_prob_list), modal_prob_list)
            outputs = t_model(inputs, mask_code)
            y_pred_prob[i] = outputs[0].cpu().numpy()
            y_pred[i] = np.argmax(y_pred_prob[i], axis=0)
            y_labels[i] = np.argmax(labels[0].cpu().numpy(), axis=0)
            if y_pred[i] == y_labels[i]:
                train_correct_sum += 1
        t_mcc = matthews_corrcoef(y_labels, y_pred)
        t_bac = balanced_accuracy_score(y_labels, y_pred)
        t_acc = train_correct_sum / train_simple_cnt
        t_f1_score = f1_score(y_labels, y_pred, average='weighted')
        t_recall = recall_score(y_labels, y_pred, average='weighted')
        t_spe = recall_score(y_labels, y_pred, average='weighted')  # pos_label=0,
        t_auc = roc_auc_score(y_labels, y_pred_prob, average='weighted', multi_class='ovo')
        t_ap = average_precision_score(y_labels, y_pred_prob, average='weighted')
        t_precision = precision_score(y_labels, y_pred, average='weighted')
    pe = [t_mcc, t_bac, t_acc, t_f1_score, t_recall, t_spe, t_auc, t_ap, t_precision]
    # print_performance_evaluation(pe)
    return pe


def print_performance_evaluation(t_pe):
    print("    t_acc   t_f1_scor  t_spe      t_sen     t_auc     t_precision")
    print("%10.4f%10.4f%10.4f%10.4f%10.4f%10.4f" % (t_pe[0], t_pe[1], t_pe[2], t_pe[3], t_pe[4], t_pe[5]))
    return
